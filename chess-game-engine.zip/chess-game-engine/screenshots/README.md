Real screenshots go here: `desktop.png`, `mobile.png`, `analysis.png`, `settings.png`.
Run `npm run dev`, capture each view, then add an image section to the main README.
