---
name: Bug report
about: Something is broken
labels: bug
---
**What happened?**

**Steps to reproduce / FEN or PGN**

**Expected behaviour**

**Browser / OS**
