---
name: Feature request
about: Suggest an improvement
labels: enhancement
---
**Problem / idea**

**Proposed solution**
