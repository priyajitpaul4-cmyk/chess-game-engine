## Summary

## Checklist
- [ ] `npm test` passes
- [ ] `npm run build` passes
- [ ] Engine code does not import React; UI does not import search code
- [ ] Docs updated if behaviour changed
