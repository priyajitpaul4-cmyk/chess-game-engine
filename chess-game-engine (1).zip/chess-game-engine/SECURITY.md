# Security Policy
This is a client-side application with no server and no user accounts. Settings are stored in `localStorage`.
To report a vulnerability, open a private security advisory on the repository (Security → Advisories) rather than a public issue. Only the latest release is supported.
