# Roadmap
**Done:** board and rules, FEN/PGN, evaluation, negamax/alpha-beta, ordering, iterative deepening, quiescence, transposition table, worker, analysis panel, clocks, settings, tests, CI/deploy.
**Next:** custom move generator with make/unmake and perft tests against chess.js · Zobrist hashing · mobility evaluation · null-move pruning and late-move reductions · SVG piece set · saved-game slots · verifying the Stockfish adapter with a bundled build.
