# Evaluation
Material (100/320/330/500/900) + centre-based piece-square values + doubled/isolated/passed pawns + bishop pair + development + rook open files + king pawn shield (middlegame) / king centralisation (endgame) + tempo. Not yet: true mobility, which needs a faster move generator.
