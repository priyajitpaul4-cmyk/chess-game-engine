# UCI
- **Custom engine (partial):** `CustomEngineAdapter` posts JSON messages named after UCI commands (`uci`, `isready`, `ucinewgame`, `position`, `go`, `quit`) to the worker, which replies with `info` and `bestmove` messages. It is UCI-shaped, not a UCI text stream. `stop` is implemented by restarting the worker because a synchronous search cannot read messages.
- **Stockfish (experimental):** `StockfishAdapter` speaks real UCI text (`position fen …`, `go depth D movetime T`, parses `info`/`bestmove`, supports `stop`). Place a single-file Stockfish.js build at `public/stockfish/stockfish.js`.
Both implement `ChessEngine`, so the UI does not depend on which one is used. Best moves cross the boundary in UCI notation (`e2e4`).
