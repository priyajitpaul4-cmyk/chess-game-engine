# Engine

Pipeline: position → legal moves (chess.js) → move ordering → negamax/alpha-beta → quiescence → evaluation → best move.

## Feature status (checked against the code)
| Feature | Status | Where |
|---|---|---|
| Negamax + alpha-beta | Implemented | `src/engine/search/Search.ts` |
| Move ordering (TT move, MVV-LVA, promotions, killers, history) | Implemented | `Search.ts` |
| Iterative deepening with time limit | Implemented | `Search.ts` |
| Quiescence (captures and promotions, stand-pat) | Implemented; checks are not searched | `Search.ts` |
| Transposition table (EXACT/LOWER/UPPER) | Implemented; keyed by FEN string, not Zobrist | `Search.ts` |
| Check extension, mate-distance scoring, draw scoring | Implemented | `Search.ts` |
| Evaluation: material, centre-based piece-square, pawn structure, bishop pair, development, rook files, king shield | Implemented | `src/engine/evaluation/Evaluation.ts` |
| Opening book | Partial: 6 short lines, optional | `src/engine/opening/OpeningBook.ts` |
| Web Worker | Implemented | `src/workers/chessEngine.worker.ts` |
| UCI | Partial: JSON commands named after UCI (`uci`, `isready`, `ucinewgame`, `position`, `go`, `quit`); no text protocol, no `setoption`; stopping restarts the worker | worker + `CustomEngineAdapter` |
| Stockfish adapter | Experimental: real UCI client, needs a user-supplied `stockfish.js`, not exercised by tests | `StockfishAdapter.ts` |
| Zobrist hashing, custom move generator, mobility, null-move pruning, late-move reduction | Not implemented (see roadmap) | — |
