# ♟️ Chess Game + AI Engine

A browser-based chess application powered by a custom chess engine.

**Live demo:** _add your GitHub Pages URL here after the first deploy_ (`https://<user>.github.io/<repo>/`)

## Screenshots
_Not added yet — see [`screenshots/README.md`](screenshots/README.md) for the capture steps and the image block to paste in here._

## Features
- All legal rules: castling, en passant, promotion, check/checkmate/stalemate, threefold, 50-move, insufficient material
- Click, drag and keyboard moves · legal-move hints · last-move and check highlight · flip board · undo/redo
- Human vs Human, vs AI (either colour), AI vs AI · 5 difficulties · custom depth/time
- Clocks (1+0 … 30+0) with increment, pause and timeout · FEN/PGN copy & import · persisted settings · themes · sound
- Analysis panel: evaluation, depth, nodes, time, best move, principal variation
- Experimental Stockfish support via a user-supplied `public/stockfish/stockfish.js`

## Architecture
```mermaid
flowchart TD
  UI[React UI] --> GC[GameController · chess.js]
  UI --> EA[ChessEngine interface]
  EA --> CA[CustomEngineAdapter]
  EA --> SA[StockfishAdapter]
  CA -->|UCI-style commands| W[Web Worker]
  W --> S[Searcher]
  S --> EV[Evaluation]
  S --> TT[Transposition table]
  W --> OB[Opening book]
  SA -->|UCI text| SF[Stockfish.js worker]
```

## Engine algorithms
Implemented: negamax, alpha-beta, iterative deepening, quiescence, transposition table (FEN-string key), MVV-LVA / killer / history ordering, check extension, small opening book. Partial: UCI-style worker protocol. Experimental: Stockfish adapter. Not implemented: Zobrist hashing, custom move generator, mobility, null-move pruning. See [docs/engine.md](docs/engine.md).

## Search
Iterative deepening runs negamax with alpha-beta to depth 1, 2, 3… keeping the last completed result; at depth 0 quiescence resolves captures. Details: [docs/search.md](docs/search.md).

## Evaluation
Material, piece-square, pawn structure, bishop pair, development, rook files, king shield. Details: [docs/evaluation.md](docs/evaluation.md).

## Folder structure
```
.github/        CI, Pages deploy, issue & PR templates
docs/           architecture, engine, search, evaluation, uci, roadmap
public/         favicon, optional stockfish/
src/app         App shell
src/components  board, game, moves, engine, dialogs (UI only)
src/game        GameController, GameSettings
src/adapters    ChessEngine, Custom/Stockfish adapters
src/workers     engine worker (UCI-style loop)
src/engine      search, evaluation, opening (no React)
src/hooks · src/utils notation, sound
tests/          rules + engine tests
```

## Install · develop · build · test
```
npm ci   # or: npm install (commit package-lock.json)
npm run dev
npm run build
npm test
npm run lint
```

## Deployment
Push to `main`; in the repo Settings → Pages choose **GitHub Actions**. `deploy.yml` lints, tests, builds and publishes `dist/`. Netlify/Vercel also work (build `npm run build`, output `dist`).

## Performance notes
Search runs off the main thread. Move generation is chess.js, so depth is limited by the time budget; a custom generator is the top roadmap item.

## Future improvements
Custom move generator · Zobrist hashing · mobility evaluation · pruning heuristics · SVG pieces · bundled Stockfish build. See [docs/development-roadmap.md](docs/development-roadmap.md).

## Known limitations
Unicode pieces (no SVG set yet) · no true mobility term · stopping the custom engine restarts its worker (clears the TT) · increments are not rolled back on undo.

## License
MIT
