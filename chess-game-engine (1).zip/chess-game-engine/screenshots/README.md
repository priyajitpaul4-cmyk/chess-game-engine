# Screenshots

Real screenshots of the running app go here, with these exact filenames:

| File | Viewport | What to show |
|---|---|---|
| `desktop.png` | 1440 × 900 | Full game UI mid-game: board, Game panel (clocks, captured), Moves panel, Analysis panel, control bar |
| `mobile.png` | 390 × 844 (iPhone 14) | Single-column mobile layout with the board first, controls visible |
| `analysis.png` | 1440 × 900 | A position after the AI has moved: Analysis panel showing Evaluation, Depth, Nodes, Best move, with the Moves list |
| `settings.png` | 1440 × 900 | Settings dialog open (⚙ Settings button in the header) |

## How to capture

1. `npm install && npm run dev`, then open the printed local URL in Chrome.
2. Open DevTools (F12) → Toggle device toolbar (Ctrl/Cmd+Shift+M) and set the viewport size from the table.
   Use "Responsive" for 1440 × 900 and a phone preset for mobile. The layout switches to one column at 820px and below.
3. Start a game vs AI, play 8–10 moves so the Moves and Analysis panels are populated. Pick a theme in Settings first and keep it the same for all four shots.
4. Capture with DevTools: Ctrl/Cmd+Shift+P → "Capture screenshot" (viewport only, no DevTools in the image).
5. Save each file here under its exact name.

Once all four files exist, add the image section to the main `README.md`:

```md
## Screenshots

### Desktop
![Chess Game Desktop](screenshots/desktop.png)

### Mobile
![Chess Game Mobile](screenshots/mobile.png)

### Analysis
![Chess Game Analysis](screenshots/analysis.png)

### Settings
![Chess Game Settings](screenshots/settings.png)
```
