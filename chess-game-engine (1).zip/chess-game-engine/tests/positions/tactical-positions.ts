/** Positions with a single clearly best move, used by the engine tests. */
export interface TacticalPosition { name: string; fen: string; best: string; depth: number }
export const TACTICS: TacticalPosition[] = [
  { name: 'back-rank mate', fen: '6k1/5ppp/8/8/8/8/5PPP/R5K1 w - - 0 1', best: 'Ra8#', depth: 3 },
  { name: 'queen mate on the 8th rank', fen: '7k/8/6K1/8/8/8/8/Q7 w - - 0 1', best: 'Qa8#', depth: 3 },
  { name: 'win a hanging queen', fen: '4k3/8/8/3q4/8/8/8/3RK3 w - - 0 1', best: 'Rxd5', depth: 3 },
];
