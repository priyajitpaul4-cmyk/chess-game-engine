import { describe, it, expect } from 'vitest';
import { Chess } from 'chess.js';
import { Searcher, MATE } from '../../src/engine/search/Search';
import { evaluate } from '../../src/engine/evaluation/Evaluation';

/** Plain negamax without pruning, tables or quiescence: the reference alpha-beta must agree with. */
function brute(c: Chess, depth: number, ply = 0): number {
  if (c.isCheckmate()) return -MATE + ply;
  if (c.isDraw()) return 0;
  if (depth === 0) return evaluate(c);
  let best = -Infinity;
  for (const m of c.moves()) { c.move(m); best = Math.max(best, -brute(c, depth - 1, ply + 1)); c.undo(); }
  return best;
}

describe('alpha-beta pruning', () => {
  // Quiet position: no captures, checks or promotions are reachable in 3 plies, so quiescence and extensions never trigger.
  const fen = '4k3/pppp4/8/8/8/8/4PPPP/4K3 w - - 0 1';
  it('returns the same score as unpruned negamax', () => {
    expect(new Searcher().negamax(new Chess(fen), 3, -Infinity, Infinity, 0)).toBe(brute(new Chess(fen), 3));
  });
  it('visits fewer nodes than the unpruned tree', () => {
    let full = 0;
    const count = (c: Chess, d: number) => { full++; if (d === 0) return; for (const m of c.moves()) { c.move(m); count(c, d - 1); c.undo(); } };
    count(new Chess(fen), 3);
    const s = new Searcher(); s.negamax(new Chess(fen), 3, -Infinity, Infinity, 0);
    expect(s.nodes).toBeLessThan(full);
  });
});
