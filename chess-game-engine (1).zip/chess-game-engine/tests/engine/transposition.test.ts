import { describe, it, expect } from 'vitest';
import { Chess } from 'chess.js';
import { Searcher } from '../../src/engine/search/Search';

describe('transposition table', () => {
  const fen = 'r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3';
  it('stores root entry with depth, bound and best move', () => {
    const s = new Searcher(); const r = s.search(fen, 3, 30000);
    const key = fen.split(' ').slice(0, 4).join(' ');
    const e = s.tt.get(key)!;
    expect(e.depth).toBe(3); expect(e.bound).toBe('EXACT'); expect(e.move).toBe(r.bestMove);
  });
  it('a warm table gives the same score with no more nodes', () => {
    const s = new Searcher();
    const cold = s.search(fen, 3, 30000), warm = s.search(fen, 3, 30000);
    expect(warm.score).toBe(cold.score); expect(warm.nodes).toBeLessThanOrEqual(cold.nodes);
  });
  it('clear() empties the table', () => {
    const s = new Searcher(); s.search(new Chess().fen(), 2, 30000); expect(s.tt.size).toBeGreaterThan(0);
    s.clear(); expect(s.tt.size).toBe(0);
  });
});
