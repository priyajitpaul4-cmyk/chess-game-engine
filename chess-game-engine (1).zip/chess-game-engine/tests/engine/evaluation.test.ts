import { describe, it, expect } from 'vitest';
import { Chess } from 'chess.js';
import { evaluate } from '../../src/engine/evaluation/Evaluation';

const ev = (fen: string) => evaluate(new Chess(fen));

describe('evaluation', () => {
  it('start position is balanced (only the tempo bonus)', () => expect(ev(new Chess().fen())).toBe(10));
  it('is symmetric under colour mirroring', () => {
    expect(ev('r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3'))
      .toBe(ev('rnbqkb1r/pppp1ppp/5n2/4p3/4P3/2N5/PPPP1PPP/R1BQKBNR b KQkq - 2 3'));
  });
  it('values extra material', () => expect(ev('4k3/8/8/8/8/8/8/Q3K3 w - - 0 1')).toBeGreaterThan(800));
  it('is from the side-to-move perspective', () => {
    expect(ev('4k3/8/8/8/8/8/8/Q3K3 b - - 0 1')).toBeLessThan(-800);
  });
  it('penalises doubled and isolated pawns', () => {
    expect(ev('4k3/8/8/8/8/P7/P7/4K3 w - - 0 1')).toBeLessThan(ev('4k3/8/8/8/8/8/PP6/4K3 w - - 0 1'));
  });
  it('rewards a passed pawn', () => {
    expect(ev('4k3/8/4P3/8/8/8/8/4K3 w - - 0 1')).toBeGreaterThan(ev('4k3/4p3/4P3/8/8/8/8/4K3 w - - 0 1') + 100);
  });
  it('rewards the bishop pair', () => {
    expect(ev('4k3/8/8/8/8/8/8/2B1KB2 w - - 0 1')).toBeGreaterThan(ev('4k3/8/8/8/8/8/8/2B1K1N1 w - - 0 1') + 20);
  });
});
