import { describe, it, expect } from 'vitest';
import { Chess } from 'chess.js';
import { Searcher, MATE } from '../../src/engine/search/Search';
import { bookMove } from '../../src/engine/opening/OpeningBook';
import { TACTICS } from '../positions/tactical-positions';

describe('search', () => {
  for (const t of TACTICS) {
    it(`finds the best move: ${t.name}`, () => {
      expect(new Searcher().search(t.fen, t.depth, 20000).bestMove).toBe(t.best);
    });
  }
  it('reports a mate score for a forced mate', () => {
    const r = new Searcher().search(TACTICS[0].fen, 3, 20000);
    expect(r.score).toBeGreaterThan(MATE - 10);
  });
  it('iterative deepening reports each completed depth and a principal variation', () => {
    const depths: number[] = [];
    const r = new Searcher().search(new Chess().fen(), 3, 30000, i => depths.push(i.depth));
    expect(depths).toEqual([1, 2, 3]);
    expect(r.pv.length).toBeGreaterThan(0);
    expect(r.nodes).toBeGreaterThan(0);
  });
  it('respects the time limit but still returns a legal move', () => {
    const r = new Searcher().search(new Chess().fen(), 12, 150);
    expect(r.bestMove).toBeTruthy();
    expect(() => new Chess().move(r.bestMove!)).not.toThrow();
  });
  it('declares stalemate a draw (score 0) instead of a win', () => {
    expect(new Searcher().negamax(new Chess('7k/5Q2/6K1/8/8/8/8/8 b - - 0 1'), 2, -Infinity, Infinity, 0)).toBe(0);
  });
  it('opening book returns a legal move and nothing for unknown positions', () => {
    const m = bookMove(new Chess().fen());
    expect(() => new Chess().move(m!)).not.toThrow();
    expect(bookMove('4k3/8/8/8/8/8/8/4K2R w - - 0 1')).toBeNull();
  });
});
