import { describe, it, expect } from 'vitest';
import { sanToUci, uciPvToSan } from '../../src/utils/notation';
const START = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
describe('notation', () => {
  it('converts SAN <-> UCI', () => {
    expect(sanToUci(START, 'Nf3')).toBe('g1f3');
    expect(uciPvToSan(START, ['e2e4', 'e7e5', 'g1f3'])).toEqual(['e4', 'e5', 'Nf3']);
  });
});
