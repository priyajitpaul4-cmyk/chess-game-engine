import { describe, it, expect } from 'vitest';
import { GameController } from '../../src/game/GameController';

const at = (fen: string) => { const g = new GameController(); expect(g.loadFen(fen)).toBe(true); return g; };

describe('special rules', () => {
  it('forbids castling through an attacked square', () => {
    expect(at('4k3/8/8/8/8/8/5r2/4K2R w K - 0 1').move('e1', 'g1')).toBeNull();
  });
  it('allows castling queenside when clear', () => {
    expect(at('r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1').move('e1', 'c1')?.san).toBe('O-O-O');
  });
  it('en passant is only legal when the target square is set', () => {
    expect(at('4k3/8/8/3pP3/8/8/8/4K3 w - - 0 1').move('e5', 'd6')).toBeNull();
    expect(at('4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 1').move('e5', 'd6')?.captured).toBe('p');
  });
  it('a pinned piece cannot move off the pin line', () => {
    expect(at('4r1k1/8/8/8/8/8/4B3/4K3 w - - 0 1').move('e2', 'd3')).toBeNull();
  });
  it('must resolve check', () => {
    const g = at('4k3/8/8/8/8/8/4r3/4K3 w - - 0 1');
    expect(g.status().check).toBe(true); expect(g.move('e1', 'e2')?.captured).toBe('r');
  });
});
describe('draws', () => {
  it('threefold repetition', () => {
    const g = new GameController();
    ['Nf3', 'Nf6', 'Ng1', 'Ng8', 'Nf3', 'Nf6', 'Ng1', 'Ng8'].forEach(s => g.moveSan(s));
    expect(g.status()).toMatchObject({ over: true, text: expect.stringMatching(/repetition/) });
  });
  it('fifty-move rule', () => {
    expect(at('8/8/4k3/8/8/4K3/8/7R w - - 100 80').status().text).toMatch(/50-move/);
  });
  it('insufficient material', () => {
    expect(at('k7/8/8/8/8/8/8/K7 w - - 0 1').status().text).toMatch(/insufficient/);
  });
  it('captured pieces are tracked per side', () => {
    const g = at('4k3/8/8/3p4/4P3/8/8/4K3 w - - 0 1'); g.move('e4', 'd5');
    expect(g.captured().w).toEqual(['p']);
  });
});
