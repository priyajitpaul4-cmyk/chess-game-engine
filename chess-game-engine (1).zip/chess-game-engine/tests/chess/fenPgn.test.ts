import { describe, it, expect } from 'vitest';
import { GameController } from '../../src/game/GameController';

const play = (g: GameController, sans: string[]) => sans.forEach(s => expect(g.moveSan(s)).not.toBeNull());

describe('FEN', () => {
  it('round-trips', () => {
    const g = new GameController(); play(g, ['e4', 'c5', 'Nf3']);
    const h = new GameController(); expect(h.loadFen(g.fen())).toBe(true); expect(h.fen()).toBe(g.fen());
  });
  it('rejects malformed FEN and keeps the current game', () => {
    const g = new GameController(); const before = g.fen();
    for (const bad of ['', 'garbage', '8/8/8/8/8/8/8 w - - 0 1']) expect(g.loadFen(bad)).toBe(false);
    expect(g.fen()).toBe(before);
  });
});
describe('PGN', () => {
  it('round-trips a game', () => {
    const g = new GameController(); play(g, ['e4', 'e5', 'Nf3', 'Nc6', 'Bb5', 'a6']);
    const h = new GameController(); expect(h.loadPgn(g.pgn())).toBe(true);
    expect(h.fen()).toBe(g.fen()); expect(h.history().map(m => m.san)).toEqual(g.history().map(m => m.san));
  });
  it('rejects an illegal move sequence', () => {
    expect(new GameController().loadPgn('1. e4 e4 2. Qxh9')).toBe(false);
  });
});
