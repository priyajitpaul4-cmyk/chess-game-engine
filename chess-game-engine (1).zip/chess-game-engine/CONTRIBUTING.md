# Contributing
1. Fork and create a branch. 2. `npm install`, `npm test`. 3. Keep layers separate (UI → GameController → EngineAdapter → Worker → Engine). 4. Add tests for rules/engine changes. 5. Open a PR using the template.
