import type { Color, PieceSymbol } from 'chess.js';
import { glyph } from '../chess-board/ChessBoard';

export function PromotionDialog({ color, onPick }: { color: Color; onPick: (p: PieceSymbol) => void }) {
  return (
    <div className="modal" role="dialog" aria-modal="true" aria-label="Choose promotion piece">
      <div className="card">
        {(['q', 'r', 'b', 'n'] as PieceSymbol[]).map(t => (
          <button key={t} aria-label={`Promote to ${t}`} onClick={() => onPick(t)}>{glyph(color, t)}</button>
        ))}
      </div>
    </div>
  );
}
