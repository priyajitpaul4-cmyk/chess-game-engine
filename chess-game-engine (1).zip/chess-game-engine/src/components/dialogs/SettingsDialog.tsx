import { useEffect } from 'react';
import type { Settings } from '../../game/GameSettings';
import { LEVELS } from '../../game/GameSettings';

type Props = { s: Settings; patch: (p: Partial<Settings>) => void; onClose: () => void };
export function SettingsDialog({ s, patch, onClose }: Props) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);
  const toggle = (k: 'coordinates' | 'hints' | 'lastMove' | 'sound' | 'animations', label: string) => (
    <label className="row"><input type="checkbox" checked={s[k]} onChange={e => patch({ [k]: e.target.checked })} /> {label}</label>
  );
  return (
    <div className="modal" role="dialog" aria-modal="true" aria-label="Settings" onClick={onClose}>
      <div className="card settings" onClick={e => e.stopPropagation()}>
        <h2>Settings</h2>
        <label>Board theme<select value={s.theme} onChange={e => patch({ theme: e.target.value as Settings['theme'] })}>
          <option value="classic">Classic</option><option value="green">Green</option><option value="slate">Slate</option></select></label>
        <label>Engine<select value={s.engine} onChange={e => patch({ engine: e.target.value as Settings['engine'] })}>
          <option value="custom">Custom engine</option><option value="stockfish">Stockfish (needs public/stockfish/stockfish.js)</option></select></label>
        <label>Difficulty<select value={s.level} onChange={e => patch({ level: e.target.value })}>
          {Object.keys(LEVELS).map(l => <option key={l}>{l}</option>)}</select></label>
        <label>Search depth override (0 = preset)<input type="number" min={0} max={20} value={s.depth}
          onChange={e => patch({ depth: Math.max(0, Number(e.target.value) || 0) })} /></label>
        <label>Thinking time ms (0 = preset)<input type="number" min={0} step={100} value={s.timeMs}
          onChange={e => patch({ timeMs: Math.max(0, Number(e.target.value) || 0) })} /></label>
        {toggle('coordinates', 'Coordinates')}{toggle('hints', 'Legal move hints')}{toggle('lastMove', 'Last move highlight')}
        {toggle('sound', 'Sound')}{toggle('animations', 'Animations')}
        <button onClick={onClose}>Done</button>
      </div>
    </div>
  );
}
