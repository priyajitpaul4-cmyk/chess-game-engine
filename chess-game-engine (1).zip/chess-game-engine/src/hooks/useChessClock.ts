import { useEffect, useRef, useState } from 'react';
import type { Color } from 'chess.js';

export interface ClockConfig { baseMs: number; incMs: number }

/** Drift-free clock: elapsed time comes from performance.now deltas, increment is added after each move. */
export function useChessClock(cfg: ClockConfig | null, turn: Color, moves: number, running: boolean,
  resetKey: number, onTimeout: (c: Color) => void) {
  const base = cfg?.baseMs ?? 0;
  const times = useRef({ w: base, b: base });
  const prev = useRef({ turn, moves });
  const cb = useRef(onTimeout); cb.current = onTimeout;
  const [, force] = useState(0);
  useEffect(() => { times.current = { w: base, b: base }; prev.current = { turn, moves }; force(n => n + 1); }, [base, resetKey]);
  useEffect(() => {
    if (cfg && moves === prev.current.moves + 1) times.current[prev.current.turn] += cfg.incMs;
    prev.current = { turn, moves };
  }, [moves]);
  useEffect(() => {
    if (!cfg || !running) return;
    let last = performance.now();
    const id = setInterval(() => {
      const now = performance.now(); times.current[turn] -= now - last; last = now;
      if (times.current[turn] <= 0) { times.current[turn] = 0; clearInterval(id); cb.current(turn); }
      force(n => n + 1);
    }, 100);
    return () => clearInterval(id);
  }, [cfg, running, turn]);
  return times.current;
}
