/// <reference lib="webworker" />
import { Searcher } from '../engine/search/Search';
import { bookMove } from '../engine/opening/OpeningBook';
import { sanToUci } from '../utils/notation';

const START = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
let fen = START;
const searcher = new Searcher();
const post = (m: unknown) => (self as unknown as Worker).postMessage(m);

/** UCI-style command loop. bestMove is returned in UCI notation (e2e4), PV in SAN. */
self.onmessage = (e: MessageEvent) => {
  const m = e.data;
  try {
    switch (m.cmd) {
      case 'uci': post({ type: 'uciok' }); break;
      case 'isready': post({ type: 'readyok' }); break;
      case 'ucinewgame': searcher.clear(); fen = START; break;
      case 'position': fen = m.fen; break;
      case 'go': {
        const b = m.useBook ? bookMove(fen) : null;
        if (b) { post({ type: 'bestmove', result: { bestMove: sanToUci(fen, b), depth: 0, score: 0, nodes: 0, timeMs: 0, pv: [b] } }); break; }
        const r = searcher.search(fen, m.depth, m.movetime, info => post({ type: 'info', info }));
        post({ type: 'bestmove', result: { ...r, bestMove: r.bestMove ? sanToUci(fen, r.bestMove) : null } });
        break;
      }
      case 'quit': self.close(); break;
    }
  } catch (err) { post({ type: 'error', message: String(err) }); }
};
