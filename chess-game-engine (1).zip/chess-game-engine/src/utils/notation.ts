import { Chess } from 'chess.js';
export function sanToUci(fen: string, san: string): string {
  const m = new Chess(fen).move(san);
  return m.from + m.to + (m.promotion ?? '');
}
export function uciPvToSan(fen: string, pv: string[]): string[] {
  const c = new Chess(fen), out: string[] = [];
  for (const u of pv) {
    try { out.push(c.move({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] }).san); } catch { break; }
  }
  return out;
}
