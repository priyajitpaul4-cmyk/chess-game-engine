let ctx: AudioContext | null = null;
export function playMoveSound(capture = false) {
  try {
    ctx ??= new AudioContext();
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.frequency.value = capture ? 220 : 440; o.type = 'triangle';
    g.gain.setValueAtTime(0.12, ctx.currentTime); g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.12);
    o.connect(g).connect(ctx.destination); o.start(); o.stop(ctx.currentTime + 0.12);
  } catch { /* audio unsupported: ignore */ }
}
