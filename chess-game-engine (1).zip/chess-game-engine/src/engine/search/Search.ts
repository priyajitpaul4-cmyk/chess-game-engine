import { Chess, type Move } from 'chess.js';
import { evaluate, VALUE } from '../evaluation/Evaluation';

export const MATE = 100000;
type Bound = 'EXACT' | 'LOWER' | 'UPPER';
interface TTEntry { depth: number; score: number; bound: Bound; move?: string }
export interface SearchInfo { depth: number; score: number; nodes: number; timeMs: number; pv: string[] }
export interface SearchOut extends SearchInfo { bestMove: string | null }

/** Negamax + alpha-beta, iterative deepening, quiescence, transposition table, killers, history, MVV-LVA. */
export class Searcher {
  tt = new Map<string, TTEntry>();
  private killers: string[][] = [];
  private hist = new Map<string, number>();
  nodes = 0;
  private stopped = false;
  private deadline = Infinity;

  clear() { this.tt.clear(); this.hist.clear(); this.killers = []; }
  private key(c: Chess) { return c.fen().split(' ').slice(0, 4).join(' '); }

  private order(moves: Move[], ttMove: string | undefined, ply: number): Move[] {
    const score = (m: Move) => {
      if (m.san === ttMove) return 1e6;
      if (m.captured) return 1e5 + 10 * VALUE[m.captured] - VALUE[m.piece]; // MVV-LVA
      if (m.promotion) return 9e4 + VALUE[m.promotion];
      if (this.killers[ply]?.includes(m.san)) return 8e4;
      return this.hist.get(m.piece + m.to) ?? 0;
    };
    return moves.map(m => [score(m), m] as const).sort((a, b) => b[0] - a[0]).map(x => x[1]);
  }

  private tick() { if ((++this.nodes & 2047) === 0 && Date.now() > this.deadline) this.stopped = true; }

  /** Quiescence: resolve captures/promotions so we never evaluate mid-exchange (horizon effect). */
  private qs(c: Chess, alpha: number, beta: number, ply: number): number {
    this.tick(); if (this.stopped) return 0;
    if (c.isCheckmate()) return -MATE + ply;
    if (c.isDraw()) return 0;
    const stand = evaluate(c);
    if (stand >= beta) return stand;
    alpha = Math.max(alpha, stand);
    const tactical = this.order(c.moves({ verbose: true }).filter(m => m.captured || m.promotion), undefined, ply);
    for (const m of tactical) {
      c.move(m.san); const s = -this.qs(c, -beta, -alpha, ply + 1); c.undo();
      if (this.stopped) return 0;
      if (s >= beta) return s;
      if (s > alpha) alpha = s;
    }
    return alpha;
  }

  negamax(c: Chess, depth: number, alpha: number, beta: number, ply: number): number {
    this.tick(); if (this.stopped) return 0;
    if (c.isCheckmate()) return -MATE + ply;   // prefer faster mates
    if (c.isDraw()) return 0;                  // stalemate, 50-move, repetition, insufficient material
    if (c.inCheck()) depth++;                  // check extension
    if (depth <= 0) return this.qs(c, alpha, beta, ply);

    const k = this.key(c), e = this.tt.get(k), alpha0 = alpha, beta0 = beta;
    if (e && e.depth >= depth && ply > 0) {
      if (e.bound === 'EXACT') return e.score;
      if (e.bound === 'LOWER') alpha = Math.max(alpha, e.score); else beta = Math.min(beta, e.score);
      if (alpha >= beta) return e.score;
    }
    let best = -Infinity, bestMove: string | undefined;
    for (const m of this.order(c.moves({ verbose: true }), e?.move, ply)) {
      c.move(m.san); const s = -this.negamax(c, depth - 1, -beta, -alpha, ply + 1); c.undo();
      if (this.stopped) return 0;
      if (s > best) { best = s; bestMove = m.san; }
      if (s > alpha) alpha = s;
      if (alpha >= beta) { // beta cutoff: remember the quiet move that caused it
        if (!m.captured) {
          (this.killers[ply] ??= []).unshift(m.san);
          this.killers[ply].length = Math.min(2, this.killers[ply].length);
          this.hist.set(m.piece + m.to, (this.hist.get(m.piece + m.to) ?? 0) + depth * depth);
        }
        break;
      }
    }
    this.tt.set(k, { depth, score: best, move: bestMove, bound: best <= alpha0 ? 'UPPER' : best >= beta0 ? 'LOWER' : 'EXACT' });
    return best;
  }

  /** Iterative deepening; returns the best fully completed iteration. */
  search(fen: string, maxDepth: number, timeMs: number, onInfo?: (i: SearchInfo) => void): SearchOut {
    const c = new Chess(fen), start = Date.now();
    this.deadline = start + timeMs; this.stopped = false; this.nodes = 0;
    const rootKey = this.key(c);
    let out: SearchOut = { bestMove: null, depth: 0, score: 0, nodes: 0, timeMs: 0, pv: [] };
    for (let d = 1; d <= maxDepth; d++) {
      const score = this.negamax(c, d, -Infinity, Infinity, 0);
      if (this.stopped && out.bestMove) break;
      const bestMove = this.tt.get(rootKey)?.move ?? null;
      out = { bestMove, depth: d, score, nodes: this.nodes, timeMs: Date.now() - start, pv: this.pv(fen, d) };
      onInfo?.(out);
      if (this.stopped || Math.abs(score) > MATE - 100) break;
    }
    return out;
  }

  private pv(fen: string, max: number): string[] {
    const c = new Chess(fen), pv: string[] = [];
    for (let i = 0; i < max; i++) {
      const m = this.tt.get(this.key(c))?.move; if (!m) break;
      try { c.move(m); pv.push(m); } catch { break; }
    }
    return pv;
  }
}
