import type { Chess, PieceSymbol } from 'chess.js';

export const VALUE: Record<PieceSymbol, number> = { p: 100, n: 320, b: 330, r: 500, q: 900, k: 0 };
const PASSED = [0, 5, 10, 20, 35, 60, 100, 0];

/** Centre-distance piece-square value. f = file 0..7, r = rank 0..7 relative to the piece's own side. */
function pst(t: PieceSymbol, f: number, r: number, endgame: boolean): number {
  const c = 3.5 - Math.max(Math.abs(f - 3.5), Math.abs(r - 3.5)); // 0 (edge) .. 3 (centre)
  switch (t) {
    case 'p': return r * 6 + (f >= 2 && f <= 5 ? c * 4 : 0);
    case 'n': return c * 12 - 20;
    case 'b': return c * 6 - 5;
    case 'r': return (r === 6 ? 15 : 0) + (f >= 2 && f <= 5 ? 4 : 0);
    case 'q': return c * 3;
    default: return endgame ? c * 12 : r === 0 ? (f === 6 || f === 2 ? 25 : f === 4 ? 0 : 8) : -25;
  }
}

/** Static evaluation in centipawns from the SIDE TO MOVE's point of view. */
export function evaluate(chess: Chess): number {
  const board = chess.board();
  let nonPawn = 0;
  const pawns: { w: number[][]; b: number[][] } = {
    w: [[], [], [], [], [], [], [], []], b: [[], [], [], [], [], [], [], []],
  };
  const bishops = { w: 0, b: 0 };
  for (let i = 0; i < 8; i++) for (let j = 0; j < 8; j++) {
    const p = board[i][j]; if (!p) continue;
    if (p.type === 'p') pawns[p.color][j].push(7 - i); else if (p.type !== 'k') nonPawn += VALUE[p.type];
  }
  const endgame = nonPawn < 2600;
  let score = 0;
  for (let i = 0; i < 8; i++) for (let j = 0; j < 8; j++) {
    const p = board[i][j]; if (!p) continue;
    const s = p.color === 'w' ? 1 : -1, rank = 7 - i, rel = p.color === 'w' ? rank : 7 - rank;
    score += s * (VALUE[p.type] + pst(p.type, j, rel, endgame));
    if (p.type === 'b') bishops[p.color]++;
    if ((p.type === 'n' || p.type === 'b') && rel > 0) score += s * 8; // development
    if (p.type === 'r' && !pawns[p.color][j].length)                  // rook on open / half-open file
      score += s * (pawns[p.color === 'w' ? 'b' : 'w'][j].length ? 10 : 20);
    if (p.type === 'k' && !endgame) {                                 // king safety: pawn shield
      let shield = 0;
      for (const f of [j - 1, j, j + 1]) shield += (pawns[p.color][f] ?? []).filter(r2 => { const rr = p.color === 'w' ? r2 : 7 - r2; return rr === rel + 1 || rr === rel + 2; }).length;
      score += s * shield * 8;
    }
    if (p.type === 'p') {
      const own = pawns[p.color], opp = pawns[p.color === 'w' ? 'b' : 'w'];
      if (own[j].length > 1) score -= s * 12;                                  // doubled
      if (!own[j - 1]?.length && !own[j + 1]?.length) score -= s * 10;         // isolated
      const blocked = [j - 1, j, j + 1].some(f => (opp[f] ?? []).some(or => (p.color === 'w' ? or > rank : or < rank)));
      if (!blocked) score += s * PASSED[rel];                                  // passed
    }
  }
  if (bishops.w >= 2) score += 30;
  if (bishops.b >= 2) score -= 30;
  return (chess.turn() === 'w' ? score : -score) + 10; // +10 tempo
}
