import { Chess } from 'chess.js';

/** Optional, replaceable book: position key -> candidate SAN moves. Built from lines, so transpositions work. */
const LINES = [
  'e4 e5 Nf3 Nc6 Bc4 Bc5', 'e4 e5 Nf3 Nc6 Bb5 a6 Ba4 Nf6 O-O Be7',
  'e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 a6', 'e4 e6 d4 d5 Nc3 Nf6',
  'd4 d5 c4 e6 Nc3 Nf6', 'd4 Nf6 c4 g6 Nc3 Bg7 e4 d6',
];
const key = (c: Chess) => c.fen().split(' ').slice(0, 4).join(' ');
const book = new Map<string, Set<string>>();
for (const line of LINES) {
  const c = new Chess();
  for (const san of line.split(' ')) {
    const k = key(c);
    if (!book.has(k)) book.set(k, new Set());
    book.get(k)!.add(san);
    c.move(san);
  }
}
export function bookMove(fen: string): string | null {
  const opts = book.get(key(new Chess(fen)));
  if (!opts) return null;
  const a = [...opts];
  return a[Math.floor(Math.random() * a.length)];
}
