export interface Settings {
  theme: 'classic' | 'green' | 'slate'; coordinates: boolean; hints: boolean; lastMove: boolean;
  sound: boolean; animations: boolean; engine: 'custom' | 'stockfish'; level: string;
  depth: number; timeMs: number; // 0 = use the difficulty preset
}
export const LEVELS: Record<string, { depth: number; timeMs: number }> = {
  Beginner: { depth: 2, timeMs: 400 }, Easy: { depth: 3, timeMs: 800 }, Medium: { depth: 4, timeMs: 2000 },
  Hard: { depth: 6, timeMs: 4000 }, Expert: { depth: 10, timeMs: 8000 },
};
export const CLOCKS: Record<string, { baseMs: number; incMs: number } | null> = {
  Off: null, '1+0': { baseMs: 60e3, incMs: 0 }, '3+2': { baseMs: 180e3, incMs: 2e3 }, '5+0': { baseMs: 300e3, incMs: 0 },
  '10+5': { baseMs: 600e3, incMs: 5e3 }, '15+10': { baseMs: 900e3, incMs: 10e3 }, '30+0': { baseMs: 1800e3, incMs: 0 },
};
export const DEFAULTS: Settings = {
  theme: 'classic', coordinates: true, hints: true, lastMove: true, sound: true, animations: true,
  engine: 'custom', level: 'Medium', depth: 0, timeMs: 0,
};
const KEY = 'chess-engine:settings';
export function loadSettings(): Settings {
  try { return { ...DEFAULTS, ...JSON.parse(localStorage.getItem(KEY) ?? '{}') }; } catch { return DEFAULTS; }
}
export function saveSettings(s: Settings) { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch { /* storage unavailable */ } }
