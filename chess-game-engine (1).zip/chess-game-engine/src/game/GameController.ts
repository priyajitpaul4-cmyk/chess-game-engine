import { Chess, type Move, type Square, type PieceSymbol, type Color } from 'chess.js';

export interface GameStatus { text: string; over: boolean; check: boolean }

/** Owns game state + rules (chess.js). No UI and no engine code lives here. */
export class GameController {
  private chess = new Chess();
  private redoStack: Move[] = [];

  fen() { return this.chess.fen(); }
  pgn() { return this.chess.pgn(); }
  turn(): Color { return this.chess.turn(); }
  board() { return this.chess.board(); }
  history(): Move[] { return this.chess.history({ verbose: true }); }
  canUndo() { return this.chess.history().length > 0; }
  canRedo() { return this.redoStack.length > 0; }

  legalMovesFrom(sq: Square): Move[] { return this.chess.moves({ square: sq, verbose: true }); }

  /** Returns the move, or null if illegal (never throws). */
  move(from: Square, to: Square, promotion?: PieceSymbol): Move | null {
    try {
      const m = this.chess.move({ from, to, promotion });
      this.redoStack = [];
      return m;
    } catch { return null; }
  }
  moveSan(san: string): Move | null {
    try { const m = this.chess.move(san); this.redoStack = []; return m; } catch { return null; }
  }
  moveUci(u: string): Move | null { return this.move(u.slice(0, 2) as Square, u.slice(2, 4) as Square, (u[4] || undefined) as PieceSymbol | undefined); }
  undo() { const m = this.chess.undo(); if (m) this.redoStack.push(m); return m; }
  redo() { const m = this.redoStack.pop(); if (!m) return null; return this.chess.move(m.san); }
  reset() { this.chess = new Chess(); this.redoStack = []; }

  loadFen(fen: string): boolean {
    try { const c = new Chess(); c.load(fen.trim()); this.chess = c; this.redoStack = []; return true; }
    catch { return false; }
  }
  loadPgn(pgn: string): boolean {
    try { const c = new Chess(); c.loadPgn(pgn.trim()); this.chess = c; this.redoStack = []; return true; }
    catch { return false; }
  }

  kingInCheckSquare(): Square | null {
    if (!this.chess.inCheck()) return null;
    const t = this.chess.turn();
    for (const row of this.chess.board())
      for (const p of row) if (p && p.type === 'k' && p.color === t) return p.square;
    return null;
  }

  captured(): { w: PieceSymbol[]; b: PieceSymbol[] } {
    const out = { w: [] as PieceSymbol[], b: [] as PieceSymbol[] };
    for (const m of this.history()) if (m.captured) out[m.color].push(m.captured);
    return out; // out.w = black pieces captured by White
  }

  status(): GameStatus {
    const c = this.chess;
    const side = c.turn() === 'w' ? 'White' : 'Black';
    if (c.isCheckmate()) return { text: `Checkmate — ${side === 'White' ? 'Black' : 'White'} wins`, over: true, check: true };
    if (c.isStalemate()) return { text: 'Draw by stalemate', over: true, check: false };
    if (c.isInsufficientMaterial()) return { text: 'Draw — insufficient material', over: true, check: false };
    if (c.isThreefoldRepetition()) return { text: 'Draw by threefold repetition', over: true, check: false };
    if (c.isDraw()) return { text: 'Draw by 50-move rule', over: true, check: false };
    return { text: c.inCheck() ? `${side} is in check` : `${side} to move`, over: false, check: c.inCheck() };
  }
}
