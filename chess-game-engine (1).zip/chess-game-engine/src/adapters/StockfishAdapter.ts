import type { ChessEngine, SearchInfo, SearchOptions, SearchResult } from './EngineAdapter';
import { uciPvToSan } from '../utils/notation';

/**
 * Real UCI client for a Stockfish.js build. Put a single-file build (e.g. stockfish-nnue-16-single.js)
 * at public/stockfish/stockfish.js — it is loaded as a classic worker.
 */
export class StockfishAdapter implements ChessEngine {
  readonly name = 'Stockfish';
  private w: Worker;
  private fen = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
  private pending?: { resolve: (r: SearchResult) => void; reject: (e: Error) => void; onInfo?: (i: SearchInfo) => void };
  private last: SearchInfo = { depth: 0, score: 0, nodes: 0, timeMs: 0, pv: [] };
  private ignore = 0;

  constructor(url = `${import.meta.env.BASE_URL}stockfish/stockfish.js`) {
    this.w = new Worker(url);
    this.w.onmessage = e => this.line(String(e.data));
    this.w.onerror = () => { const p = this.pending; this.pending = undefined; p?.reject(new Error('Stockfish failed to load (see public/stockfish)')); };
    this.w.postMessage('uci'); this.w.postMessage('isready');
  }
  private sign() { return this.fen.split(' ')[1] === 'w' ? 1 : -1; }
  private line(l: string) {
    if (l.startsWith('info') && l.includes(' pv ')) {
      const g = (k: string) => l.match(new RegExp(`${k} (-?\\d+)`))?.[1];
      const mate = g('score mate'), cp = g('score cp');
      const score = mate ? Math.sign(Number(mate)) * (100000 - 2 * Math.abs(Number(mate))) : Number(cp ?? 0);
      this.last = { depth: Number(g('depth') ?? 0), score: score * this.sign(), nodes: Number(g('nodes') ?? 0),
        timeMs: Number(g('time') ?? 0), pv: uciPvToSan(this.fen, l.split(' pv ')[1].trim().split(' ')) };
      this.pending?.onInfo?.(this.last);
    } else if (l.startsWith('bestmove')) {
      if (this.ignore > 0) { this.ignore--; return; }
      const mv = l.split(' ')[1], p = this.pending; this.pending = undefined;
      p?.resolve({ ...this.last, bestMove: mv && mv !== '(none)' ? mv : null });
    }
  }
  newGame() { this.w.postMessage('ucinewgame'); }
  setPosition(fen: string) { this.fen = fen; }
  search(o: SearchOptions, onInfo?: (i: SearchInfo) => void) {
    return new Promise<SearchResult>((resolve, reject) => {
      this.pending = { resolve, reject, onInfo };
      this.w.postMessage(`position fen ${this.fen}`);
      this.w.postMessage(`go depth ${o.depth} movetime ${o.timeMs}`);
    });
  }
  stop() {
    if (this.pending) { this.ignore++; this.pending.reject(new Error('stopped')); this.pending = undefined; this.w.postMessage('stop'); }
  }
  dispose() { this.w.postMessage('quit'); this.w.terminate(); }
}
