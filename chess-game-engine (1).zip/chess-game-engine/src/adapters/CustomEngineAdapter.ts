import type { ChessEngine, SearchInfo, SearchOptions, SearchResult } from './EngineAdapter';

type Pending = { resolve: (r: SearchResult) => void; reject: (e: Error) => void; onInfo?: (i: SearchInfo) => void };

/** Talks to the engine Web Worker with a UCI-style command protocol. */
export class CustomEngineAdapter implements ChessEngine {
  readonly name = 'Custom Engine';
  private w!: Worker;
  private fen = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
  private pending?: Pending;

  constructor() { this.spawn(); }

  private spawn() {
    this.w = new Worker(new URL('../workers/chessEngine.worker.ts', import.meta.url), { type: 'module' });
    this.w.onmessage = e => this.onMessage(e.data);
    this.w.onerror = () => this.fail(new Error('Engine worker failed'));
    this.w.postMessage({ cmd: 'uci' });
    this.w.postMessage({ cmd: 'isready' });
  }
  private sign() { return this.fen.split(' ')[1] === 'w' ? 1 : -1; }
  private onMessage(m: any) {
    if (m.type === 'info') this.pending?.onInfo?.({ ...m.info, score: m.info.score * this.sign() });
    else if (m.type === 'bestmove') {
      const p = this.pending; this.pending = undefined;
      p?.resolve({ ...m.result, score: m.result.score * this.sign() });
    } else if (m.type === 'error') this.fail(new Error(m.message));
  }
  private fail(e: Error) { const p = this.pending; this.pending = undefined; p?.reject(e); }

  newGame() { this.w.postMessage({ cmd: 'ucinewgame' }); }
  setPosition(fen: string) { this.fen = fen; this.w.postMessage({ cmd: 'position', fen }); }
  search(o: SearchOptions, onInfo?: (i: SearchInfo) => void) {
    return new Promise<SearchResult>((resolve, reject) => {
      this.pending = { resolve, reject, onInfo };
      this.w.postMessage({ cmd: 'go', depth: o.depth, movetime: o.timeMs, useBook: o.useBook });
    });
  }
  /** A synchronous search can't read messages, so stopping = restarting the worker. */
  stop() {
    if (!this.pending) return;
    this.w.terminate(); this.fail(new Error('stopped')); this.spawn(); this.w.postMessage({ cmd: 'position', fen: this.fen });
  }
  dispose() { this.w.terminate(); }
}
