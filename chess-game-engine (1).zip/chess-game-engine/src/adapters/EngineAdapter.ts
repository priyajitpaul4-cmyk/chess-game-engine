export interface SearchOptions { depth: number; timeMs: number; useBook: boolean }
export interface SearchInfo { depth: number; score: number; nodes: number; timeMs: number; pv: string[] }
export interface SearchResult extends SearchInfo { bestMove: string | null }

/** The only engine surface the UI/GameController knows. Score is in centipawns from White's view. */
export interface ChessEngine {
  readonly name: string;
  newGame(): void;
  setPosition(fen: string): void;
  search(opts: SearchOptions, onInfo?: (i: SearchInfo) => void): Promise<SearchResult>;
  stop(): void;
  dispose(): void;
}
