import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  base: './',
  // Searches run on a synchronous move generator, so give engine tests room.
  test: { environment: 'node', testTimeout: 30000 },
});
